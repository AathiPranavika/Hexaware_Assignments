package EcomDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import Connect.DataConnect;
import Exception.CustIdValid;
import Exception.OrderIdValid;
import Exception.ProdIdValid;
import Model.Customer;
import Model.Product;
public class ImpEcomDAO 
{
   Connection con;
   PreparedStatement stat;
   public static int currentCustomerId=0;
   public static String currentCustomerName=null;
   public static String currentCustomerEmail=null;
   public ImpEcomDAO()
   {
	   con=DataConnect.getConnect();
   }
   
   public void register(Customer obj)
   {
	   try
	   {
	   stat = con.prepareStatement("INSERT INTO customers(name, email, password) VALUES (?, ?, ?)");
	   stat.setString(1, obj.getName());
	   stat.setString(2, obj.getEmail());
	   stat.setString(3, obj.getPassword());
       
	   stat.execute();
	   System.out.println("Customer registered successfully");
	   }
	   
	   catch(Exception e)
	   {
			System.out.println("❌ Email already registered:"+e.getMessage());	
	   }
	   
   }
   public void login(String email,String p)
   {
	   if (email == null || p == null || email.trim().isEmpty() || p.trim().isEmpty()) {
	        System.out.println("❌ Email and password cannot be blank.");
	        return;
	    }

	   try
	   {
	   stat=con.prepareStatement("select * from customers where email=lower(?) and password=?");
	   stat.setString(1, email);
	   stat.setString(2, p);
       
	   ResultSet rs = stat.executeQuery();

       if (rs.next()) 
       {
           System.out.println("Customer logged in successfully");
           currentCustomerId = rs.getInt("customer_id");
           currentCustomerName = rs.getString("name");
           currentCustomerEmail = rs.getString("email");
           System.out.println("Welcome "+currentCustomerName);
       } 
       else 
       {
           System.out.println("❌ Invalid email or password");
           return;
       }
	   }
	   catch(Exception e)
	   {
			System.out.println("❌ Login failed: " + e.getMessage());	
	   }
	   
   }
   public void dispCustomer()
   {
	   try
	   {
	   stat=con.prepareStatement("select * from customers");
		ResultSet rs=stat.executeQuery();
		if (!rs.next()) // true if resultSet has no rows
	       {
	           System.out.println("No customers available");
	           return;
	       }
	   System.out.println("Displaying all customer records");
       System.out.println("----------------------------------------------------");

		while(rs.next())
		{
            System.out.printf("ID: %-5d Name: %-15s Email: %-25s\n", rs.getInt(1), rs.getString(2), rs.getString(3));
		}
	   }
	   catch(Exception e)
	   {
			System.out.println(e.getMessage());	
	   }

   }
   public void delCust(String email)
   {
	   try
	   {
	   stat=con.prepareStatement("delete from customers where email=?");
	   stat.setString(1, email);
	   int c=stat.executeUpdate();
	   if(c==0)
	   {
           throw new CustIdValid(" No customer found with email: " + email);
	   }
	   else
	   {
		   System.out.println(c+" customer record deleted successfully");	   
	   }
	   
	   }
	   catch (CustIdValid e) {
	        System.out.println(e.getMessage());
	    }
	   catch(Exception e)
	   {
			System.out.println(e.getMessage());	
	   } 
   }
   public boolean addProd(Product obj)
   {
	   try
	    {
	        stat = con.prepareStatement(
	            "INSERT INTO products (name, price, description, stockQuantity) VALUES (?, ?, ?, ?)"
	        );
	        stat.setString(1, obj.getName());
	        stat.setDouble(2, obj.getPrice());
	        stat.setString(3, obj.getDescription());
	        stat.setInt(4, obj.getStockQuantity());

	        int rowsInserted = stat.executeUpdate();
	        if (rowsInserted > 0) {
	            System.out.println(" Product created successfully");
	            return true;
	        }
	        return false;
	    }
	    catch(Exception e)
	    {
	        System.out.println("x " + e.getMessage());    
	        return false;
	    }
	 
   }
   
   public void delProd(int id) 
   {
	   try
	   {
	   stat=con.prepareStatement("delete from products where product_id=?");
	   stat.setInt(1, id);
	   int c=stat.executeUpdate();
	   if(c==0)
	   {
           throw new ProdIdValid("Invalid product ID: " + id);
	   }
	   else
	   {
		   System.out.println(c+" product record deleted successfully");	   
	   }
	   
	   }
	   catch (ProdIdValid e)
	   {
	        System.out.println(e.getMessage());
	    } 
	   catch(Exception e)
	   {
			System.out.println(e.getMessage());	
	   } 
   }
   public void dispProd()
   {
	   try
	   {
	   stat=con.prepareStatement("select * from products");
		ResultSet rs=stat.executeQuery();
	   if (!rs.next()) // true if resultSet has no rows
       {
           System.out.println("No products available");
           return;
       }
	   System.out.println("\n Displaying all products:");
       System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------");
       System.out.printf("%-5s %-30s %-11s %-70s %-10s\n", "ID", "Name", "Price", "Description", "Stock");
       System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------");
		while(rs.next())
		{
			System.out.printf("%-5d %-30s ₹%-10.2f %-70s %-10s\n",
                    rs.getInt(1), rs.getString(2), rs.getDouble(3), rs.getString(4), rs.getString(5));		}
	   }
	   catch(Exception e)
	   {
			System.out.println(e.getMessage());	
	   }

   }
   
   public boolean addToCart(int prodId, int qty)
   {
	  try
	  {
	         //check if prod exists
	         stat = con.prepareStatement("SELECT name, stockQuantity FROM products WHERE product_id = ?");
	         stat.setInt(1, prodId);
	         ResultSet rs = stat.executeQuery();

	         if (!rs.next()) 
	            {
	                throw new ProdIdValid("Invalid product ID"+prodId);
	            }
	         String prodName = rs.getString("name");
	         int stockQty = rs.getInt("stockQuantity");
	         
	         if (stockQty == 0) {
	                System.out.println("❌ " + prodName + " is out of stock.");
	                return false;
	            }

	            if (qty > stockQty) {
	                System.out.println("❌ Only " + stockQty + " units available for " + prodName);
	                return false;
	            }
	         //insert rec to cart table
	         stat = con.prepareStatement(
	        		    "INSERT INTO cart(customer_id, product_id, quantity) VALUES (?, ?, ?)",
	        		    Statement.RETURN_GENERATED_KEYS//to retrieve the generated key
	        		);
	         stat.setInt(1, currentCustomerId);
	         stat.setInt(2, prodId);
	         stat.setInt(3, qty);	         
 
	         int inserted = stat.executeUpdate();

	         if (inserted > 0) 
	         {
	        	 return true;
	         } 
	         else
	         {
	        	 return false;
	         }
	                   
	  }
	  catch (ProdIdValid e) {
	        System.out.println(e.getMessage());
	        return false;
	    }
	  catch(Exception e)
	   {
			System.out.println(e.getMessage());	
	        return false;

	   }
   }
   public void removeFromCart(int proId)
   {
	   try
	   {
	   stat=con.prepareStatement("select * from cart where customer_id=? and product_id=?");
	   stat.setInt(1, currentCustomerId);
       stat.setInt(2, proId);
	   ResultSet rs = stat.executeQuery();

       if (!rs.next()) 
          {
              System.out.println("❌ No such item in your cart");
              return;
          }
	   stat=con.prepareStatement("delete from cart where customer_id=? and product_id=? ");
	   stat.setInt(1, currentCustomerId);
       stat.setInt(2, proId);
       
       int deleted = stat.executeUpdate();

       if (deleted > 0) 
       {
 		 System.out.println("Product successfully deleted from your cart");
      	 return;
       } 
      	return;
	   }
	   catch(Exception e)
	   {
			System.out.println(e.getMessage());	
	        return;

	   }
	   
   }
   
   public void viewCart()
   {
	   try
	   {
	   stat=con.prepareStatement("SELECT c.customer_id, c.product_id, p.name, c.quantity,p.price FROM cart c JOIN products p ON c.product_id = p.product_id WHERE c.customer_id = ?");
	   stat.setInt(1, currentCustomerId);
		ResultSet rs=stat.executeQuery();
	   if (!rs.next()) 
       {
           System.out.println("Your cart is empty");
           return;
       }
	   System.out.println("\n Items in your cart:");
       System.out.println("--------------------------------------------------------------------");
       System.out.printf("%-10s %-10s %-30s %-10s %-10s\n","Cust.Id", "P.ID", "Product Name", "Qty", "Price");
       System.out.println("--------------------------------------------------------------------");
		while(rs.next())
		{
			int custId = rs.getInt(1);
		    int prodId = rs.getInt(2);
		    String prodName = rs.getString(3);
		    int qty = rs.getInt(4);
		    double price = rs.getDouble(5);
		    System.out.printf("%-10d %-10d %-30s %-10d %-10.2f\n", custId, prodId, prodName, qty, price);
		    }
	   }
	   catch(Exception e)
	   {
			System.out.println(e.getMessage());	
	        return;

	   }
   }
   
   public boolean placeOrder(String address)
   {
	   try
	   {
		   //cal total price
		  stat=con.prepareStatement("SELECT sum(c.quantity*p.price) as tot_price FROM cart c JOIN products p ON c.product_id = p.product_id WHERE c.customer_id = ?");
		  stat.setInt(1, currentCustomerId);
		  ResultSet rs=stat.executeQuery();
	      double totalPrice = 0;
		  if(rs.next())
		  {
			  totalPrice=rs.getDouble("tot_price");
		  }
		  if (totalPrice == 0||rs.wasNull()) 
		  {
	            System.out.println(" Cart is empty. Cannot place order.");
		        return false;
	      }
		  //insert into order table
		  stat=con.prepareStatement("insert into orders (customer_id, total_price, shipping_address) values (?,?,?)",
				  Statement.RETURN_GENERATED_KEYS);
		  stat.setInt(1, currentCustomerId);
		  stat.setDouble(2, totalPrice);
		  stat.setString(3, address);
		   int rows=stat.executeUpdate();
		   if (rows > 0) 
		   {
			   //get auto generated order_id
			   ResultSet generatedKeys = stat.getGeneratedKeys();
	            int orderId = -1;

	            if (generatedKeys.next())
	            {
	                orderId = generatedKeys.getInt(1);  
	            }
			   
	            System.out.println(" Order placed successfully! Order ID: " + orderId);
	            
	            //take every prod from login cust cart
	            stat = con.prepareStatement("SELECT product_id, quantity FROM cart WHERE customer_id = ?");
	            stat.setInt(1, currentCustomerId);
	            rs = stat.executeQuery();

	            while (rs.next()) 
	            {
	                int productId = rs.getInt("product_id");
	                int qty = rs.getInt("quantity");
                    //update stock quantity
	                stat=con.prepareStatement("update products set stockQuantity=stockQuantity-? where product_id=?");
	                stat.setInt(1, qty);
	                stat.setInt(2, productId);
	                int c=stat.executeUpdate();
	                
	                //insert into order items
	                stat = con.prepareStatement(
	                    "INSERT INTO order_items (order_id, product_id, quantity) VALUES (?, ?, ?)"
	                );
	                stat.setInt(1, orderId);
	                stat.setInt(2, productId);
	                stat.setInt(3, qty);
	                stat.executeUpdate();

	            }
	            //clear cart after placing order
	            stat = con.prepareStatement("DELETE FROM cart WHERE customer_id = ?");
	            stat.setInt(1, currentCustomerId);
	            stat.executeUpdate();
	            System.out.println("Your cart has been cleared.");
		        return true;
	       } 
		   else 
	        {
	            System.out.println("❌ Failed to place the order.");
		        return false;

	        }
		   
	   }
	   catch(Exception e)
	   {
			System.out.println(e.getMessage());	
	        return false;

	   }
   }
   
   public void viewOrder()
   {
	   try
	   {
		  stat=con.prepareStatement("select * from orders where customer_id=?");
		  stat.setInt(1, currentCustomerId);
		  ResultSet rs=stat.executeQuery();
		  if(!rs.isBeforeFirst())
		  {
			  System.out.println("No orders placed!!");
		  }
		  else
		  {
			  System.out.println("\nHello " + currentCustomerName + "!!");
	            System.out.println("Your order details:");
	            System.out.println("----------------------------------------");

	            while (rs.next())
	            {
	                int orderId = rs.getInt("order_id");
	                double totalPrice = rs.getDouble("total_price");
	                String address = rs.getString("shipping_address");
	                Timestamp orderTimestamp = rs.getTimestamp("order_date");

	                //calc delivery date
	                LocalDateTime orderDate = orderTimestamp.toLocalDateTime();
	                LocalDateTime deliveryDate = orderDate.plusDays(5);
	                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

	                System.out.println("Order ID            : " + orderId);
	                System.out.printf ("Total Price         : ₹%.2f\n", totalPrice);
	                System.out.println("Shipping Address    : " + address);
	                System.out.println("Order Date          : " + formatter.format(orderDate));
	                System.out.println("Estimated Delivery  : " + formatter.format(deliveryDate));
	                System.out.println("--------------------------------------------------------");
	            }  
		  }
	   }
	   catch(Exception e)
	   {
			System.out.println(e.getMessage());	
	        return;

	   }
   }

   public void order_items(int id)
   {
	   try
	   {
		   stat = con.prepareStatement("SELECT p.name, oi.quantity FROM order_items oi JOIN products p ON oi.product_id = p.product_id WHERE oi.order_id = ?");	
		   stat.setInt(1, id);
		  ResultSet rs=stat.executeQuery();
		  if (!rs.next()) 
	       {
	            throw new OrderIdValid("❌ No such order found with ID: " + id);
	       }
		   System.out.println("Displaying all ordered items of id "+id);
           System.out.println("-----------------------------------");

		   
			while(rs.next())
			{
				String productName = rs.getString("p.name");
			    int quantity = rs.getInt("oi.quantity");
			    System.out.printf("• %-28s | %-10d\n", productName, quantity);
			}

	   }
	   catch (OrderIdValid e) {
	        System.out.println(e.getMessage());
	    } 
	   catch(Exception e)
	   {
			System.out.println(e.getMessage());	
	        return;

	   }
   }
}
