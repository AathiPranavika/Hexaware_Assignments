package Services;
import java.util.Scanner;
import EcomDAO.ImpEcomDAO;
import Model.Customer;
import Model.Product;

public class EcomService
{
	Scanner sc;
	ImpEcomDAO edao;
 public EcomService()
 {
	 sc=new Scanner(System.in);
	 edao=new ImpEcomDAO();
 }
 public void registerCustomer()
 {
	 System.out.print("Enter Name: ");
	    String name = sc.nextLine();
	    if (name == null || name.trim().isEmpty()) {
	        System.out.println("❌ Name cannot be blank.");
	        return;
	    }

	    System.out.print("Enter Email: ");
	    String email = sc.nextLine();
	    if (email == null || email.trim().isEmpty() || !email.contains("@")) {
	        System.out.println("❌ Invalid email format. Must contain '@'.");
	        return;
	    }

	    System.out.print("Enter Password: ");
	    String password = sc.nextLine();
	    if (password == null || password.trim().isEmpty() || password.length() < 6) 
	    {
	        System.out.println("❌ Password must be at least 6 characters long.");
	        return;
	    }
      Customer obj=new Customer(name,email,password);
      edao.register(obj);
 }
 
 public void loginCustomer()
 {
	 System.out.print("Enter Email: ");
     String email = sc.nextLine();
     System.out.print("Enter Password: ");
     String password = sc.nextLine();
      edao.login(email,password);
 }
 public void dispCustomer()
 {
	 edao.dispCustomer();
 }
 public void deleteCustomer()
 {
	 System.out.print("Enter Email of customer to be deleted: ");
     String email = sc.nextLine();
     edao.delCust(email);
 }
 
 public void addProduct()
 {
	 System.out.print("Enter Product Name: ");
     String name = sc.nextLine();

     System.out.print("Enter Product Price: ");
     double price = sc.nextDouble();
     sc.nextLine(); 

     System.out.print("Enter Product Description: ");
     String description = sc.nextLine();

     System.out.print("Enter Stock Quantity: ");
     int stockQuantity = sc.nextInt();
     if(stockQuantity<=0)
     {
         System.out.println("❌ Stock quantity cant be 0.Try again!!\n");   
         return;
     }
     sc.nextLine();
     Product product = new Product(name, price, description, stockQuantity);
     edao.addProd(product);

 }
 public void delProduct()
 {
	 System.out.println("Enter product id");
     int id = sc.nextInt();
     
     edao.delProd(id);
 }
 
 public void dispProducts()
 {
	 edao.dispProd();
 }
 public void addToCart()
 {
	 if(ImpEcomDAO.currentCustomerId==0)
     {
         System.out.println("❌ Error: No customer is logged in!");
         return;
     }
	 
	 dispProducts();
	 boolean addedAny = false;

	    while (true) 
	    {
	        System.out.println("Enter product id to add in cart!! To exit press 0");
	        int cartProId = sc.nextInt();
	        if (cartProId == 0) {
	            System.out.println("Exiting product selection.");
	            break;
	        }

	        System.out.println("Enter quantity");
	        int qty = sc.nextInt();
	        boolean added = edao.addToCart(cartProId, qty);
	        if (added) 
	        {
	            addedAny = true;
	        }
	        
	    }
	    if (addedAny)
	    {
	        System.out.println("Items have been successfully added to your cart!");
	    } else 
	    {
	        System.out.println("No items were added to your cart. Please try again.");
	    }
	 
 }
 public void removeFromCart()
 {
	 if(ImpEcomDAO.currentCustomerId==0)
     {
         System.out.println("❌ Error: No customer is logged in!");
         return;
     }
     System.out.println("Enter product id to remove from cart!!");
     int cartProId = sc.nextInt();
	 edao.removeFromCart(cartProId);
 }
 
 public void viewCart()
 {
	 if(ImpEcomDAO.currentCustomerId==0)
     {
         System.out.println("❌ Error: No customer is logged in!");
         return;
     }
	 
	 edao.viewCart();
 }
 
 public void placeOrder()
 {
	 if(ImpEcomDAO.currentCustomerId==0)
     {
         System.out.println("❌ Error: No customer is logged in!");
         return;
     }
	 sc.nextLine();
	 System.out.print("Enter shipping address: ");
     String address = sc.nextLine();
     edao.placeOrder(address);
 }
 
 public void viewOrder()
 {
	 if(ImpEcomDAO.currentCustomerId==0)
     {
         System.out.println("❌ Error: No customer is logged in!");
         return;
     }
	 edao.viewOrder();
 }
 
 public void viewOrder_items()
 {
	 if(ImpEcomDAO.currentCustomerId==0)
     {
         System.out.println("❌ Error: No customer is logged in!");
         return;
     }
	 System.out.println("enter order id");
	 int id=sc.nextInt();
	 edao.order_items(id);
 }
 
 
}

