package Exception;

public class ProdIdValid extends Exception {
    public ProdIdValid(String msg) 
    {
        super("Product Error: " + msg);
    }
}

