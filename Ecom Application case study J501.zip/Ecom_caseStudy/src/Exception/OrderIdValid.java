package Exception;

public class OrderIdValid extends Exception
{
	public OrderIdValid(String message) {
        super(message);
    }
}
