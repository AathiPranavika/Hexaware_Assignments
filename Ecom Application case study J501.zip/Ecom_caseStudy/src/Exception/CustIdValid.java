package Exception;

public class CustIdValid extends Exception
{
	public CustIdValid(String message) {
        super(message);
    }
}
