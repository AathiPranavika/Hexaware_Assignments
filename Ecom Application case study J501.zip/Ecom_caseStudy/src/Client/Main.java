package Client;
import java.util.Scanner;
import Services.EcomService;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
	    EcomService ser=new EcomService();
        while (true) 
        {
        	System.out.println("\n=== E-Commerce System ===");
        	System.out.println("1.  Register Customer");
        	System.out.println("2.  Login Customer");
        	System.out.println("3.  Add Product");
        	System.out.println("4.  Delete Product");
        	System.out.println("5.  Show All Products");
        	System.out.println("6.  Show All Customers");
        	System.out.println("7.  Add Product to Cart");
        	System.out.println("8.  Delete Customer");
        	System.out.println("9.  Remove Product from Cart");
        	System.out.println("10. View Cart");
        	System.out.println("11. Place Order");
        	System.out.println("12. View Orders");
        	System.out.println("13. View Ordered Items");
        	System.out.println("14. Exit");
        	System.out.print("Enter your choice: ");

            
            int choice = sc.nextInt();
            sc.nextLine(); 
            
            switch(choice) {
                case 1:
                	ser.registerCustomer();
                    break;
                case 2:
                	ser.loginCustomer();
                    break;
                case 6:
                    ser.dispCustomer();
                    break; 
                case 8:
                    ser.deleteCustomer();
                    break;     
                case 3:
                    ser.addProduct();
                    break;
                case 4:
                    ser.delProduct();
                    break;
                   
                case 5:
                    ser.dispProducts();
                    break;
                
                case 7:
                    ser.addToCart();
                    break;
                case 9:
                	ser.removeFromCart();
                	break;
                case 10:
                    ser.viewCart();
                    break; 	
                case 11:
                    ser.placeOrder();
                    break; 
                case 12:
                	ser.viewOrder();
                	break;
                case 13:	
                	ser.viewOrder_items();
                	break;
                case 14:
                    System.out.println("Exiting... Thank you!");
                    return;
                default:
                    System.out.println("Invalid choice! Try again.");
            }
        }

    }

}

