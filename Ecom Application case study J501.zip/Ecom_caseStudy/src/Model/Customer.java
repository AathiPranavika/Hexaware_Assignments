package Model;
public class Customer {
private int customerId;
private String name;
private String email;
private String password;

public Customer() {
}

public Customer(String var1, String var2, String var3) {
   this.name = var1;
   this.email = var2;
   this.password = var3;
}

public int getCustomerId() {
   return this.customerId;
}

public void setCustomerId(int var1) {
   this.customerId = var1;
}

public String getName() {
   return this.name;
}

public void setName(String var1) {
   this.name = var1;
}

public String getEmail() {
   return this.email;
}

public void setEmail(String var1) {
   this.email = var1;
}

public String getPassword() {
   return this.password;
}

public void setPassword(String var1) {
   this.password = var1;
}

public String toString() {
   return "Customer { customerId = " + this.customerId + ", name = " + this.name + ", email = " + this.email + " }";
}
}
