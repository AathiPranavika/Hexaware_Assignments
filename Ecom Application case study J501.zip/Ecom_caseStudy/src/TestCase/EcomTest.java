package TestCase;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Connect.DataConnect;
import org.junit.jupiter.api.*;
import EcomDAO.ImpEcomDAO;
import Model.Customer;
import Model.Product;
//to execute test case in order
@TestMethodOrder(MethodOrderer.OrderAnnotation.class) 
class EcomTest {

    static ImpEcomDAO edao;
    static Connection con = DataConnect.getConnect();
    static int prodId = 0;
    static int custId = 0;

    @BeforeAll
    static void setup() {
        edao = new ImpEcomDAO();
        Customer testCustomer = new Customer("Test User", "testuser@gmail.com", "test123");
        edao.register(testCustomer);
        edao.login("testuser@gmail.com", "test123");

        try
        {
        	//to get cust_id
            PreparedStatement getCust = con.prepareStatement("SELECT customer_id FROM customers WHERE email = ?");
            getCust.setString(1, "testuser@gmail.com");
            ResultSet rs = getCust.executeQuery();

            if (rs.next())
            {
                custId = rs.getInt("customer_id");
            } 
            

        } 
        catch (Exception e) 
        {
            System.out.println("❌ Failed to setup customer: " + e.getMessage());
        }
    }

    @Test
    @Order(1) 
    void testProductCreation() 
    {
        Product product = new Product("Samsung Smart Watch", 999.99, "Smart features available", 10);
        boolean result = edao.addProd(product);
        assertTrue(result,"Product created successfully.");
        //to get prod_id
        try {
            PreparedStatement st = con.prepareStatement("SELECT product_id FROM products WHERE name='Samsung Smart Watch'");
            ResultSet rs = st.executeQuery();
            if (rs.next()) 
            {
                prodId = rs.getInt("product_id");
            } 
            
        } 
        catch (Exception e) 
        {
            fail("Failed to retrieve product ID: " + e.getMessage());
        }
    }

    @Test
    @Order(2) 
    void testAddProductToCartSuccess() {
        if (prodId == 0) {
            fail("Product ID not set. Run product creation test first.");
        }
        boolean result = edao.addToCart(prodId, 1);
        assertTrue(result, "Product added to cart successfully.");
    }

    @Test
    @Order(3) 
    void testPlaceOrderSuccess() {
        boolean result = edao.placeOrder("New post office street, Mumbai");
        assertTrue(result, "Order placed successfully from cart.");
    }

    @AfterAll
    static void cleanUp() {
        try {
            // Delete cart entries
            PreparedStatement delCart = con.prepareStatement("DELETE FROM cart WHERE customer_id = ? AND product_id = ?");
            delCart.setInt(1, custId);
            delCart.setInt(2, prodId);
            delCart.executeUpdate();

            // Delete order entries
            PreparedStatement delOrderItems = con.prepareStatement("DELETE FROM order_items WHERE product_id = ?");
            delOrderItems.setInt(1, prodId);
            delOrderItems.executeUpdate();

            // Delete order
            PreparedStatement delOrders = con.prepareStatement("DELETE FROM orders WHERE customer_id = ?");
            delOrders.setInt(1, custId);
            delOrders.executeUpdate();

            // Delete product
            PreparedStatement delProd = con.prepareStatement("DELETE FROM products WHERE product_id = ?");
            delProd.setInt(1, prodId);
            delProd.executeUpdate();

            // Delete customer
            PreparedStatement delCust = con.prepareStatement("DELETE FROM customers WHERE customer_id = ?");
            delCust.setInt(1, custId);
            delCust.executeUpdate();

            System.out.println("Test data cleanup done.");
        } 
        catch (Exception e) {
            e.printStackTrace();
            System.out.println("❌ Cleanup failed: " + e.getMessage());
        }
    }
}
