package Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

import Dao.TravelDao;
import Model.Concert;
import Model.Concert_type;
import Model.Event;
import Model.Event_Type;
import Model.Movie;
import Model.Movie_type;
import Model.Sports;
import Model.SportsTeam_type;
import Model.Venue;

public class EventServiceProviderImpl implements IEventServiceProvider {

    TravelDao tDao;
    Scanner scanner;

    public EventServiceProviderImpl() {
        tDao = new TravelDao();
        scanner = new Scanner(System.in);
    }

    public void addVenue() {
        System.out.print("Enter Venue Name: ");
        String venueName = scanner.nextLine();

        System.out.print("Enter Venue Address: ");
        String address = scanner.nextLine();

        Venue obj = new Venue(venueName, address);
        tDao.addVenue(obj);
    }

    public void addEvent() {
        System.out.print("Enter Event Name: ");
        String eventName = scanner.nextLine();

        System.out.print("Enter Event Date (YYYY-MM-DD): ");
        LocalDate eventDate = LocalDate.parse(scanner.nextLine());

        System.out.print("Enter Event Time (HH:MM:SS): ");
        LocalTime eventTime = LocalTime.parse(scanner.nextLine());

        System.out.print("Enter Venue ID: ");
        int venueId = Integer.parseInt(scanner.nextLine());

        System.out.print("Enter Total Seats: ");
        int totalSeats = Integer.parseInt(scanner.nextLine());

        System.out.print("Enter Ticket Price: ");
        double ticketPrice = Double.parseDouble(scanner.nextLine());

        System.out.print("Enter Event Type (MOVIE, CONCERT, SPORTS): ");
        Event_Type eventType = Event_Type.valueOf(scanner.nextLine().toUpperCase());

        Event event = null;

        switch (eventType) {
            case MOVIE:
                System.out.print("Enter Movie Genre (ACTION, DRAMA, COMEDY): ");
                Movie_type genre = Movie_type.valueOf(scanner.nextLine().toUpperCase());

                System.out.print("Enter Actor Name: ");
                String actorName = scanner.nextLine();

                System.out.print("Enter Actress Name: ");
                String actressName = scanner.nextLine();

                event = new Movie(eventName, eventDate, eventTime, venueId,
                        totalSeats, ticketPrice, eventType, genre, actorName, actressName);
                break;

            case CONCERT:
                System.out.print("Enter Artist Name: ");
                String artist = scanner.nextLine();

                System.out.print("Enter Concert Type (ROCK, POP, CLASSICAL): ");
                Concert_type concertType = Concert_type.valueOf(scanner.nextLine().toUpperCase());

                event = new Concert(eventName, eventDate, eventTime, venueId,
                        totalSeats, totalSeats, ticketPrice, eventType, artist, concertType);
                break;

            case SPORTS:
                System.out.print("Enter Sport Name: ");
                String sportName = scanner.nextLine();

                System.out.print("Enter Team 1: ");
                SportsTeam_type team1 = SportsTeam_type.valueOf(scanner.nextLine().toUpperCase());

                System.out.print("Enter Team 2: ");
                SportsTeam_type team2 = SportsTeam_type.valueOf(scanner.nextLine().toUpperCase());

                event = new Sports(eventName, eventDate, eventTime, venueId,
                        totalSeats, ticketPrice, eventType, sportName, team1, team2);
                break;

            default:
                System.out.println("Invalid Event Type.");
                return;
        }

        tDao.addEvent(event);
    }

    public void deleteEvent() {
        System.out.print("Enter Event ID to delete: ");
        int eventId = scanner.nextInt();
        tDao.deleteEvent(eventId);
        System.out.println("Event deleted successfully!");
    }

    public void getEvent() {
        System.out.print("Enter Event ID to get details: ");
        int eventId = scanner.nextInt();
        tDao.getEvent(eventId);
    }

    public void getAllEvent() {
        tDao.printAllEvents();
    }

    public void updateAvailableSeats() {
        System.out.print("Enter Event ID: ");
        int eventId = scanner.nextInt();

        System.out.print("Enter New Available Seats: ");
        int newSeats = scanner.nextInt();

        boolean update = tDao.updateEvent(eventId, newSeats);
        if (update) {
            System.out.println("Seats updated successfully!");
        } else {
            System.out.println("Event not found.");
        }
    }
}
