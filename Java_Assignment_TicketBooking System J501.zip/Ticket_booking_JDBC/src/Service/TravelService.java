package Service;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import Dao.TravelDao;
import Exception.EventNotFound;
import Exception.InvalidBookingId;
import Model.Concert;
import Model.Concert_type;
import Model.Customer;
import Model.Event;
import Model.Event_Type;
import Model.Movie;
import Model.Movie_type;
import Model.Sports;
import Model.SportsTeam_type;
import Model.Venue;

public class TravelService {

    TravelDao tDao;
    Scanner scanner;

    public TravelService() {
    	tDao = new TravelDao();
    	scanner= new Scanner(System.in);  
    }
    public void addVenue() 
    {
    System.out.print("Enter Venue Name: ");
    String venueName = scanner.nextLine();

    System.out.print("Enter Venue Address: ");
    String address = scanner.nextLine();
    Venue obj = new Venue(venueName,address);

    tDao.addVenue(obj);
    }
    
    public void registerCustomer() {
            System.out.print("Enter Name: ");
            String name = scanner.nextLine();

            System.out.print("Enter Email: ");
            String email = scanner.nextLine();

            System.out.print("Enter Phone Number: ");
            String phone = scanner.nextLine();

            if (phone.length()!=10)
            {
                System.out.println("Invalid phone number.");
                return;
            }

            Customer customer = new Customer(name, email, phone);
            tDao.registerCustomer(customer); 
        
    }
    public void addEvent() {
        System.out.print("Enter Event Name: ");
        String eventName = scanner.nextLine();

        System.out.print("Enter Event Date (YYYY-MM-DD): ");
        LocalDate eventDate = LocalDate.parse(scanner.nextLine());

        System.out.print("Enter Event Time (HH:MM:SS): ");
        LocalTime eventTime = LocalTime.parse(scanner.nextLine());

        System.out.print("Enter Venue ID: ");
        int venueId = Integer.parseInt(scanner.nextLine());

        System.out.print("Enter Total Seats: ");
        int totalSeats = Integer.parseInt(scanner.nextLine());

        System.out.print("Enter Ticket Price: ");
        double ticketPrice = Double.parseDouble(scanner.nextLine());

        System.out.print("Enter Event Type (MOVIE, CONCERT, SPORTS): ");
        Event_Type eventType = Event_Type.valueOf(scanner.nextLine().toUpperCase());

        Event event = null;

        switch (eventType) {
            case MOVIE:
                System.out.print("Enter Movie Genre (ACTION, DRAMA, COMEDY): ");
                Movie_type genre = Movie_type.valueOf(scanner.nextLine().toUpperCase());

                System.out.print("Enter Actor Name: ");
                String actorName = scanner.nextLine();

                System.out.print("Enter Actress Name: ");
                String actressName = scanner.nextLine();

                event = new Movie(eventName, eventDate, eventTime, venueId,
                                  totalSeats, ticketPrice, eventType,
                                  genre, actorName, actressName);
                break;

            case CONCERT:
                System.out.print("Enter Artist Name: ");
                String artist = scanner.nextLine();

                System.out.print("Enter Concert Type (ROCK, POP, CLASSICAL): ");
                Concert_type concertType = Concert_type.valueOf(scanner.nextLine().toUpperCase());

                // Available seats same as total seats at creation
                event = new Concert(eventName, eventDate, eventTime, venueId,
                                    totalSeats, totalSeats, ticketPrice, eventType,
                                    artist, concertType);
                break;

            case SPORTS:
                System.out.print("Enter Sport Name (e.g., Football, Cricket): ");
                String sportName = scanner.nextLine();

                System.out.print("Enter Team 1 (e.g., INDIA, AUSTRALIA): ");
                SportsTeam_type team1 = SportsTeam_type.valueOf(scanner.nextLine().toUpperCase());

                System.out.print("Enter Team 2 (e.g., ENGLAND, PAKISTAN): ");
                SportsTeam_type team2 = SportsTeam_type.valueOf(scanner.nextLine().toUpperCase());

                event = new Sports(eventName, eventDate, eventTime, venueId,
                                   totalSeats, ticketPrice, eventType,
                                   sportName, team1, team2);
                break;

            default:
                System.out.println("Invalid Event Type.");
                return;
        }

        tDao.addEvent(event);
    }

   
    // Method to delete an event by its ID
    public void deleteEvent() {
        System.out.print("Enter Event ID to delete: ");
        int eventId = scanner.nextInt();
        tDao.deleteEvent(eventId);
        System.out.println("Event deleted successfully!");
    }

    // Method to get event details by its ID
    public void getEvent() {
        System.out.print("Enter Event ID to get details: ");
        int eventId = scanner.nextInt();
        tDao.getEvent(eventId);
       
    }
    
    public void getAllEvent() {
        tDao.printAllEvents();
       
    }

    // Method to update available seats for an event
    public void updateAvailableSeats() {
        System.out.print("Enter Event ID to update available seats: ");
        int eventId = scanner.nextInt();

        System.out.print("Enter New Available Seats: ");
        int newAvailableSeats = scanner.nextInt();

        Boolean update = tDao.updateEvent(eventId,newAvailableSeats);
        if (update) {
            System.out.println("Available seats updated successfully!");
        } else {
            System.out.println("Event not found!");
        }
    }
    
    //booking
    public void bookSeatsForEvent() {
            System.out.print("Enter Customer ID: ");
            int customerId = scanner.nextInt();

            System.out.print("Enter Event ID: ");
            int eventId = scanner.nextInt();;

            System.out.print("Enter number of seats to book: ");
            int seats = scanner.nextInt();;

            if (seats <= 0) {
                System.out.println("Number of seats must be greater than 0.");
                return;
            }

            try 
            {
                tDao.bookSeats(customerId, eventId, seats);
            } 
            catch (EventNotFound e) 
            {
                System.out.println("Oops! " + e.getMessage());
            }

        } 
    
    //cancelling
    public void cancelBookingById() 
    {
    	    System.out.print("Enter Booking ID to cancel: ");
            int bookingId = Integer.parseInt(scanner.nextLine());

            if (bookingId <= 0) 
            {
                System.out.println("Invalid Booking ID. It must be a positive number.");
                return;
            }

            try 
            {
            	tDao.cancelBooking(bookingId);
            } 
            catch (InvalidBookingId e) 
            {
                System.out.println("Cancellation failed: " + e.getMessage());
            }
          
    }
    public void printAllBookings() {
        tDao.printAllBookings();
    }
}
