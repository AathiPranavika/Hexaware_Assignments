package Service;

public interface IBookingSystemServiceProvider {
    void registerCustomer();
    void bookSeatsForEvent();
    void cancelBookingById();
    void printAllBookings();
}
