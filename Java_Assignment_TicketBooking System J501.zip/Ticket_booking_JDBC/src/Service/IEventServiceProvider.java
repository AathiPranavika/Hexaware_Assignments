package Service;

import java.time.LocalDate;
import java.time.LocalTime;
import Model.Venue;

public interface IEventServiceProvider {
    void addVenue();
    void addEvent();
    void deleteEvent();
    void getEvent();
    void getAllEvent();
    void updateAvailableSeats();
}
