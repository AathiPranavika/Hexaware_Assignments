package Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Dao.TravelDao;
import Exception.EventNotFound;
import Exception.InvalidBookingId;
import Model.Customer;

public class BookingSystemServiceProviderImpl implements IBookingSystemServiceProvider {

    TravelDao tDao;
    Scanner scanner;
    public List<Customer> customers = new ArrayList<>();
    public BookingSystemServiceProviderImpl() {
        tDao = new TravelDao();
        scanner = new Scanner(System.in);
    }

    public void registerCustomer() {
        System.out.print("Enter Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Email: ");
        String email = scanner.nextLine();

        System.out.print("Enter Phone Number: ");
        String phone = scanner.nextLine();

        if (phone.length() != 10) {
            System.out.println("Invalid phone number.");
            return;
        }

        Customer customer = new Customer(name, email, phone);
        customers.add(customer);
        tDao.registerCustomer(customer);
    }

    public void bookSeatsForEvent() {
        System.out.print("Enter Customer ID: ");
        int customerId = scanner.nextInt();

        System.out.print("Enter Event ID: ");
        int eventId = scanner.nextInt();

        System.out.print("Enter number of seats to book: ");
        int seats = scanner.nextInt();

        if (seats <= 0) {
            System.out.println("Invalid number of seats.");
            return;
        }

        try {
            tDao.bookSeats(customerId, eventId, seats);
        } catch (EventNotFound e) {
            System.out.println("Oops! " + e.getMessage());
        }
    }

    public void cancelBookingById() {
        System.out.print("Enter Booking ID to cancel: ");
        int bookingId = scanner.nextInt();

        if (bookingId <= 0) {
            System.out.println("Invalid booking ID.");
            return;
        }

        try {
            tDao.cancelBooking(bookingId);
        } catch (InvalidBookingId e) {
            System.out.println("Cancellation failed: " + e.getMessage());
        }
    }

    public void printAllBookings() {
        tDao.printAllBookings();
    }
}
