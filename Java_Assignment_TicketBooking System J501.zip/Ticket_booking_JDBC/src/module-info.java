/**
 * 
 */
/**
 * 
 */
module Travel_booking_JDBC {
	requires java.sql;
}