package Client;
import Service.BookingSystemServiceProviderImpl;
import Service.EventServiceProviderImpl;
import java.util.Scanner;

public class TicketBookingSystem {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        EventServiceProviderImpl eventService = new EventServiceProviderImpl();
        BookingSystemServiceProviderImpl bookingService = new BookingSystemServiceProviderImpl();
        while (true) {
            System.out.println("\n====== Travel Booking System Menu ======");
            System.out.println("1. Register Customer");
            System.out.println("2. Add Venue");
            System.out.println("3. Add Event");
            System.out.println("4. Delete Event");
            System.out.println("5. Get Event by ID");
            System.out.println("6. Show All Events");
            System.out.println("7. Update Available Seats");
            System.out.println("8. Book Seats");
            System.out.println("9. Cancel Booking");
            System.out.println("10. Show All Bookings");
            System.out.println("11. Exit");
            System.out.print("Enter your choice: ");
            
            int choice=sc.nextInt();

            switch (choice) {
                case 1:
                	bookingService.registerCustomer();
                    break;
                case 2:
                	eventService.addVenue();
                    break;
                case 3:
                	eventService.addEvent();
                    break;
                case 4:
                	eventService.deleteEvent();
                    break;
                case 5:
                	eventService.getEvent();
                    break;
                case 6:
                	eventService.getAllEvent();
                    break;
                case 7:
                	eventService.updateAvailableSeats();
                    break;
                case 8:
                	bookingService.bookSeatsForEvent();
                    break;
                case 9:
                	bookingService.cancelBookingById();
                    break;
                case 10:
                	bookingService.printAllBookings();
                    break;     
                case 11:
                    System.out.println("Exiting application. Thank you!");
                    sc.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
