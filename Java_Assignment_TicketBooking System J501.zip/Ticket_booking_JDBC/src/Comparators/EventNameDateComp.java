package Comparators;

import Model.Event;
import java.util.Comparator;

public class EventNameDateComp implements Comparator<Event> {
    @Override
    public int compare(Event e1, Event e2) {
        int nameCompare = e1.getEventName().compareToIgnoreCase(e2.getEventName());
        if (nameCompare != 0) {
            return nameCompare;
        }
        return e1.getEventDate().compareTo(e2.getEventDate()); // Assuming getEventDate() returns java.time.LocalDate
    }
}
