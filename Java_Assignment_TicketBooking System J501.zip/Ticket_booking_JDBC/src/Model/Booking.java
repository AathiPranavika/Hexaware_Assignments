package Model;

import java.util.*;

public class Booking {
    private Event event;
    private Map<Integer, Customer> customers; // Step 3 - Map
    private int bookedTickets;
    private double totalCost;
    private String ticketCategory;

    public Booking(Event event) {
        this.event = event;
        this.customers = new HashMap<>();
        this.bookedTickets = 0;
        this.totalCost = 0.0;
        this.ticketCategory = "Silver";
    }

   
    public void calculateBookingCost(int numTickets, String category) {
        double pricePerTicket;
        switch (category.toLowerCase()) {
            case "gold": pricePerTicket = 250.0; break;
            case "diamond": pricePerTicket = 400.0; break;
            default: pricePerTicket = 150.0; category = "Silver";
        }
        this.totalCost = numTickets * pricePerTicket;
        this.ticketCategory = category;
    }

    public void bookTickets(int numTickets, String category) {
        if (numTickets <= event.getAvailableSeats()) {
            bookedTickets += numTickets;
            calculateBookingCost(bookedTickets, category);
            event.updateAvailableTickets(numTickets);
            System.out.println(numTickets + " " + category + " tickets booked successfully.");
        } else {
            System.out.println("Not enough tickets available.");
        }
    }

    public void cancelBooking(int numTickets) {
        if (numTickets <= bookedTickets) {
            bookedTickets -= numTickets;
            event.updateAvailableTickets(numTickets);
            calculateBookingCost(bookedTickets, ticketCategory);
            System.out.println(numTickets + " tickets canceled successfully.");
        } else {
            System.out.println("You cannot cancel more tickets than booked.");
        }
    }

    public void showBookingSummary() {
        System.out.println("Tickets booked: " + bookedTickets);
        System.out.println("Ticket Category: " + ticketCategory);
        System.out.println("Total cost: ₹" + totalCost);
        System.out.println("Remaining tickets: " + event.getAvailableSeats());
    }

    public Event getEvent() {
        return event;
    }
}
