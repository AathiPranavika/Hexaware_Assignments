package Model;

public enum SportsTeam_type 
{
       INDIA,
       PAKISTAN
}
