package Model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Concert extends Event {
    private String artist;
    private Concert_type type;

    public Concert() {
        super();
    }

    public Concert(String eventName, LocalDate eventDate, LocalTime eventTime, int venueId,
                   int totalSeats,int availableSeats ,double ticketPrice, Event_Type eventType,
                   String artist, Concert_type type) 
    {
        super(eventName, eventDate, eventTime, venueId, totalSeats, ticketPrice, eventType);
        this.artist = artist;
        this.type = type;
    }
    @Override
    public String getEventCategory() {
        return "Concert";
    }
    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public Concert_type getType() {
        return type;
    }

    public void setType(Concert_type type) {
        this.type = type;
    }

    public String display_concert_details() {
        return super.displayEventDetails() + "\n"
             + "Artist: " + artist + "\n"
             + "Concert Type: " + type;
    }
}

