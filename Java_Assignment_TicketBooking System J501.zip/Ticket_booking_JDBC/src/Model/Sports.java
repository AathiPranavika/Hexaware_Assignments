package Model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Sports extends Event {
    private String sportName;
    private SportsTeam_type team1;
    private SportsTeam_type team2;

    public Sports() {
        super();
    }

    public Sports(String eventName, LocalDate eventDate, LocalTime eventTime, int venueId,
                  int totalSeats, double ticketPrice, Event_Type eventType,
                  String sportName, SportsTeam_type team1, SportsTeam_type team2) {
        super(eventName, eventDate, eventTime, venueId, totalSeats, ticketPrice, eventType);
        this.sportName = sportName;
        this.team1 = team1;
        this.team2 = team2;
    }
    @Override
    public String getEventCategory() {
        return "Sport";
    }
    public String getSportName() {
        return sportName;
    }

    public void setSportName(String sportName) {
        this.sportName = sportName;
    }

    public SportsTeam_type getTeam1() {
        return team1;
    }

    public void setTeam1(SportsTeam_type team1) {
        this.team1 = team1;
    }

    public SportsTeam_type getTeam2() {
        return team2;
    }

    public void setTeam2(SportsTeam_type team2) {
        this.team2 = team2;
    }

    public String display_sport_details() {
        return super.displayEventDetails() + "\n"
             + "Sport Name: " + sportName + "\n"
             + "Match: " + team1 + " vs " + team2;
    }
}
