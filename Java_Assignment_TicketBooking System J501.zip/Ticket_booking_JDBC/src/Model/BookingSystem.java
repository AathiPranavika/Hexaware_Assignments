package Model;

import java.util.*;
import Comparators.EventNameDateComp;
import java.util.Collections;
public class BookingSystem {
    private Map<Integer, Event> events;  
    private Map<Integer, Booking> bookings;

    public BookingSystem() {
        this.events = new HashMap<>();
        this.bookings = new HashMap<>();
    }

    public void displaySortedEvents() {
        List<Event> sortedList = new ArrayList<>(events.values()); 
        Collections.sort(sortedList, new EventNameDateComp()); 

        for (Event e : sortedList) {
            System.out.println(e.displayEventDetails());
        }
    }


    public void displayBookings() {
        for (Booking booking : bookings.values()) {
            booking.showBookingSummary();
        }
    }
}
