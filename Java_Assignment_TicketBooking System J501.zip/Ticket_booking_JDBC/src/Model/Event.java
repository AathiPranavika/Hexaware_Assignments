package Model;
import java.time.LocalDate;
import java.time.LocalTime;

public abstract class Event {
    protected String eventName;
    protected LocalDate eventDate;
    protected LocalTime eventTime;
    protected int venueId;
    protected int totalSeats;
    protected int availableSeats;
    protected double ticketPrice;
    protected Event_Type eventType;

    public Event() {}

    public Event(String eventName, LocalDate eventDate, LocalTime eventTime, int venueId,
                 int totalSeats, double ticketPrice, Event_Type eventType) {
        this.eventName = eventName;
        this.eventDate = eventDate;
        this.eventTime = eventTime;
        this.venueId = venueId;
        this.totalSeats = totalSeats;
        this.availableSeats = totalSeats;
        this.ticketPrice = ticketPrice;
        this.eventType = eventType;
    }

    // Abstract method to override
    public abstract String getEventCategory();

    public String getEventName() { return eventName; }
    public void setEventName(String eventName) { this.eventName = eventName; }

    public LocalDate getEventDate() { return eventDate; }
    public void setEventDate(LocalDate eventDate) { this.eventDate = eventDate; }

    public LocalTime getEventTime() { return eventTime; }
    public void setEventTime(LocalTime eventTime) { this.eventTime = eventTime; }

    public int getVenueId() { return venueId; }
    public void setVenueId(int venueId) { this.venueId = venueId; }

    public int getTotalSeats() { return totalSeats; }
    public void setTotalSeats(int totalSeats) { this.totalSeats = totalSeats; }

    public int getAvailableSeats() { return availableSeats; }
    public void setAvailableSeats(int availableSeats) { this.availableSeats = availableSeats; }

    public double getTicketPrice() { return ticketPrice; }
    public void setTicketPrice(double ticketPrice) { this.ticketPrice = ticketPrice; }

    public Event_Type getEventType() { return eventType; }
    public void setEventType(Event_Type eventType) { this.eventType = eventType; }

    public void bookTickets(int numTickets) {
        if (numTickets <= availableSeats) {
            availableSeats -= numTickets;
        } else {
            System.out.println("Not enough seats available.");
        }
    }

    public void cancelBooking(int numTickets) {
        if ((availableSeats + numTickets) <= totalSeats) {
            availableSeats += numTickets;
        } else {
            System.out.println("Cancel exceeds total seat count.");
        }
    }

    public int getBookedNoOfTickets() {
        return totalSeats - availableSeats;
    }

    public double calculateTotalRevenue() {
        return getBookedNoOfTickets() * ticketPrice;
    }

    public void updateAvailableTickets(int change) {
        int updated = availableSeats + change;
        if (updated >= 0 && updated <= totalSeats) {
            availableSeats = updated;
        } else {
            System.out.println("Invalid update to available tickets.");
        }
    }

    public String displayEventDetails() {
        return "Event: " + eventName + "\n"
             + "Date: " + eventDate + "\n"
             + "Time: " + eventTime + "\n"
             + "Venue ID: " + venueId + "\n"
             + "Total Seats: " + totalSeats + "\n"
             + "Available Seats: " + availableSeats + "\n"
             + "Ticket Price: ₹" + ticketPrice + "\n"
             + "Event Type: " + eventType + "\n"
             + "Category: " + getEventCategory();
    }
}
