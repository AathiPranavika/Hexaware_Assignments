package Model;
import java.time.LocalDate;
import java.time.LocalTime;
public class Movie extends Event
{
	private Movie_type genre;
    private String actorName;
    private String actressName;
 public Movie(String eventName, String eventDate, String eventTime, int venueId, int totalSeats, int availableSeats, double ticketPrice, Event_Type movie, Movie_type genre2, String actorName2, String actressName2)
 {
	 super();
 }
 
 public Movie(String eventName, LocalDate eventDate, LocalTime eventTime, int venueId,
         int totalSeats, double ticketPrice, Event_Type eventType,
         Movie_type genre, String actorName, String actressName) 
 {
	super(eventName, eventDate, eventTime, venueId, totalSeats, ticketPrice, eventType);
	this.genre = genre;
	this.actorName = actorName;
	this.actressName = actressName;
 }
 @Override
 public String getEventCategory() {
     return "Movie";
 }
 public Movie_type getGenre() { return genre; }
 public void setGenre(Movie_type genre) { this.genre = genre; }

 public String getActorName() { return actorName; }
 public void setActorName(String actorName) { this.actorName = actorName; }

 public String getActressName() { return actressName; }
 public void setActressName(String actressName) { this.actressName = actressName; }

 public String display_event_details() 
 {
     return super.displayEventDetails() + "\n"
          + "Genre: " + genre + "\n"
          + "Actor: " + actorName + "\n"
          + "Actress: " + actressName;
 }
 
}
