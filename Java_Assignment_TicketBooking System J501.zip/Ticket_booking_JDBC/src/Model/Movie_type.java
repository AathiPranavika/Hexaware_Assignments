package Model;

public enum Movie_type {
	ACTION,
    COMEDY,
    HORROR
}
