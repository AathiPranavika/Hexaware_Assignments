package Model;

public enum Event_Type
{
	MOVIE,
    SPORTS,
    CONCERT
}
