package Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Connect.DataConnect;
import Exception.EventNotFound;
import Exception.InvalidBookingId;
import Model.Concert;
import Model.Customer;
import Model.Event;
import Model.Event_Type;
import Model.Venue;

public class TravelDao {
    Connection con;
    PreparedStatement stat;

    public TravelDao() {
        con = DataConnect.getConnect();
    }

    
    //add venue
    public void addVenue(Venue venue) {
        try {
            // SQL query to insert the venue into the venue table
            String query = "INSERT INTO venue (venue_name, address) VALUES (?, ?)";

            stat = con.prepareStatement(query);

            stat.setString(1, venue.getVenueName());  
            stat.setString(2, venue.getAddress());    

            int rowsAffected = stat.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Venue added successfully.");
            }
        } catch (SQLException e) {
            System.out.println("Error while adding venue: " + e.getMessage());
        }
    }
    
    //add customer
    public void registerCustomer(Customer customer) {
        try {
            stat = con.prepareStatement("INSERT INTO customer(customer_name,email,phone_number) VALUES ( ?, ?, ?)");
            stat.setString(1, customer.getCustomerName());
            stat.setString(2, customer.getEmail());
            stat.setString(3, customer.getPhoneNumber());

            int rows = stat.executeUpdate();
            if (rows > 0) 
            {
                System.out.println("Customer registered successfully.");
            }
        } 
        catch (SQLException e) 
        {
            System.out.println("Error: " + e.getMessage());
        }
    }
    // Add a new event
    
    public void addEvent(Event event) {
        try {
            String query = "INSERT INTO event (event_name, event_date, event_time, venue_id, total_seats, available_seats, ticket_price, event_type) "
                         + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

            // Prepare the statement
            stat = con.prepareStatement(query);

            // Set the parameters for the prepared statement
            stat.setString(1, event.getEventName());
            stat.setString(2, event.getEventDate().toString());  
            stat.setString(3, event.getEventTime().toString());
            stat.setInt(4, event.getVenueId());
            stat.setInt(5, event.getTotalSeats());
            stat.setInt(6, event.getAvailableSeats());
            stat.setDouble(7, event.getTicketPrice());
            stat.setString(8, event.getEventType().toString());  

            int rowsAffected = stat.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Event added successfully.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }


    // Delete an event
    public void deleteEvent(int eventId) {
        try {
            stat = con.prepareStatement("DELETE FROM event WHERE event_id = ?");
            stat.setInt(1, eventId);

            int c = stat.executeUpdate();
            if (c > 0) {
                System.out.println("Event deleted successfully.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // Get event details by ID
    public void printAllEvents() {
        try {
            stat = con.prepareStatement("SELECT * FROM event");
            ResultSet rs = stat.executeQuery();

            // Print table headers
            System.out.printf("%-10s %-20s %-15s %-10s %-10s %-15s %-15s %-15s %-10s\n", 
                              "Event ID", "Event Name", "Event Date", "Event Time", 
                              "Venue ID", "Total Seats", "Available Seats", 
                              "Ticket Price", "Event Type");
            System.out.println("------------------------------------------------------------");

            while (rs.next()) {
                // Fetch data from result set for each event
                int id = rs.getInt("event_id");
                String name = rs.getString("event_name");
                String date = rs.getString("event_date");
                String time = rs.getString("event_time");
                int venueId = rs.getInt("venue_id");
                int totalSeats = rs.getInt("total_seats");
                int availableSeats = rs.getInt("available_seats");
                double ticketPrice = rs.getDouble("ticket_price");
                String eventTypeString = rs.getString("event_type");

                // Print the fetched values in table format
                System.out.printf("%-10d %-20s %-15s %-10s %-10d %-15d %-15d %-15.2f %-10s\n", 
                                  id, name, date, time, venueId, totalSeats, availableSeats, ticketPrice, eventTypeString);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

 // In TravelDao class
    public void getEvent(int eventId) {
        try {
            // Prepare the SQL query to fetch event details by event ID
            String query = "SELECT * FROM event WHERE event_id = ?";
            stat = con.prepareStatement(query);
            stat.setInt(1, eventId); // Set the eventId parameter

            ResultSet rs = stat.executeQuery();

            // If an event is found, print the details
            if (rs.next()) {
                // Fetch data from the result set
                String name = rs.getString("event_name");
                String date = rs.getString("event_date");
                String time = rs.getString("event_time");
                int venueId = rs.getInt("venue_id");
                int totalSeats = rs.getInt("total_seats");
                int availableSeats = rs.getInt("available_seats");
                double ticketPrice = rs.getDouble("ticket_price");
                String eventTypeString = rs.getString("event_type");

                // Print the event details
                System.out.println("Event ID: " + eventId);
                System.out.println("Event Name: " + name);
                System.out.println("Event Date: " + date);
                System.out.println("Event Time: " + time);
                System.out.println("Venue ID: " + venueId);
                System.out.println("Total Seats: " + totalSeats);
                System.out.println("Available Seats: " + availableSeats);
                System.out.println("Ticket Price: " + ticketPrice);
                System.out.println("Event Type: " + eventTypeString);
            } else {
                System.out.println("No event found with the given ID.");
            }
        } catch (SQLException e) {
            System.out.println("Error fetching event: " + e.getMessage());
        }
    }

    
    // Update event details
    public boolean updateEvent(int eventId, int newAvailableSeats) {
        try {
            // First, check if the event_id exists in the database
            String checkQuery = "SELECT COUNT(*) FROM event WHERE event_id = ?";
            stat = con.prepareStatement(checkQuery);
            stat.setInt(1, eventId);
            
            ResultSet rs = stat.executeQuery();
            
            if (rs.next() && rs.getInt(1) > 0) {
                // Event ID exists, proceed with updating available seats
                String query = "UPDATE event SET available_seats = ? WHERE event_id = ?";
                stat = con.prepareStatement(query);
                stat.setInt(1, newAvailableSeats);  // New available seats
                stat.setInt(2, eventId);  // Event ID to identify the event
                
                int rowsAffected = stat.executeUpdate();
                return rowsAffected > 0;  // Return true if the event was updated, false otherwise
            } else {
                // Event ID does not exist
                System.out.println("Event with ID " + eventId + " does not exist.");
                return false;
            }
        } catch (SQLException e) {
            System.out.println("Error updating available seats: " + e.getMessage());
            return false;  
        }
    }

    // Book seats for an event
    public void bookSeats(int customerId, int eventId, int seats) throws EventNotFound{
        try {
            PreparedStatement stat1 = con.prepareStatement("SELECT available_seats, ticket_price FROM event WHERE event_id = ?");
            stat1.setInt(1, eventId);
            ResultSet rs1 = stat1.executeQuery();

            if (!rs1.next()) {
                throw new EventNotFound("Event ID " + eventId + " not found.");
            }

            int availableSeats = rs1.getInt("available_seats");
            int price = rs1.getInt("ticket_price");

            if (availableSeats < seats) {
                System.out.println("Not enough available seats.");
                return;
            }

            int totalCost = price * seats;

            PreparedStatement stat2 = con.prepareStatement("UPDATE event SET available_seats = available_seats - ? WHERE event_id = ?");
            stat2.setInt(1, seats);
            stat2.setInt(2, eventId);
            stat2.executeUpdate();

            PreparedStatement stat3 = con.prepareStatement(
                "INSERT INTO booking (customer_id, event_id, num_tickets, total_cost, booking_date) VALUES (?, ?, ?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS
            );
            stat3.setInt(1, customerId);
            stat3.setInt(2, eventId);
            stat3.setInt(3, seats);
            stat3.setInt(4, totalCost);
            stat3.setDate(5, java.sql.Date.valueOf(java.time.LocalDate.now()));
            stat3.executeUpdate();

            ResultSet generatedKeys = stat3.getGeneratedKeys();
            if (generatedKeys.next()) {
                int bookingId = generatedKeys.getInt(1);
                System.out.println("Booking successful. Your Booking ID is " + bookingId);
            }

        } catch (SQLException e) {
            System.out.println("Error during booking: " + e.getMessage());
        }
    }

    // Cancel seats for an event
    public void cancelBooking(int bookingId) throws InvalidBookingId
    {
        try {
            // Step 1: Get event_id and num_tickets for the given booking ID
            PreparedStatement stat1 = con.prepareStatement(
                "SELECT event_id, num_tickets FROM booking WHERE booking_id = ?"
            );
            stat1.setInt(1, bookingId);
            ResultSet rs1 = stat1.executeQuery();
            if (!rs1.next()) 
            {
                throw new InvalidBookingId("No booking found with ID " + bookingId);
            }
                int eventId = rs1.getInt("event_id");
                int numTickets = rs1.getInt("num_tickets");

                // Step 2: Update available seats in the event table
                PreparedStatement stat2 = con.prepareStatement(
                    "UPDATE event SET available_seats = available_seats + ? WHERE event_id = ?"
                );
                stat2.setInt(1, numTickets);
                stat2.setInt(2, eventId);
                int updated = stat2.executeUpdate();

                // Step 3: Delete the booking
                if (updated > 0) {
                    PreparedStatement stat3 = con.prepareStatement(
                        "DELETE FROM booking WHERE booking_id = ?"
                    );
                    stat3.setInt(1, bookingId);
                    int deleted = stat3.executeUpdate();

                    if (deleted > 0) {
                        System.out.println("Booking with ID " + bookingId + " cancelled successfully.");
                    } 
                    else {
                        System.out.println("Booking record not found for deletion.");
                    }
                } 
           
        } 
        catch (SQLException e) 
        {
            System.out.println("Error during cancellation: " + e.getMessage());
        }
    }
    
    //print all bookings
    public void printAllBookings() 
    {
        String query = "SELECT * FROM booking";

        try (PreparedStatement stmt = con.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

        	System.out.println(String.format("%-12s %-12s %-10s %-8s %-12s %-12s", 
                    "Booking ID", "Customer ID", "Event ID", "Tickets", "Total Cost", "Booking Date"));

        while (rs.next()) {
        int bookingId = rs.getInt("booking_id");
        int customerId = rs.getInt("customer_id");
        int eventId = rs.getInt("event_id");
        int numTickets = rs.getInt("num_tickets");
        int totalCost = rs.getInt("total_cost");
        Date bookingDate = rs.getDate("booking_date");

        System.out.println(String.format("%-12d %-12d %-10d %-8d %-12d %-12s", 
                    bookingId, customerId, eventId, numTickets, totalCost, bookingDate));

        }
        } 
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
}
