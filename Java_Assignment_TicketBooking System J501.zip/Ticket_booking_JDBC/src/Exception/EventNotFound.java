package Exception;

public class EventNotFound extends Exception {
 public EventNotFound(String message) {
     super(message);
 }
}
