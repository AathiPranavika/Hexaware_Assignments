package Exception;

public class InvalidBookingId extends Exception {
 public InvalidBookingId(String message) {
     super(message);
 }
}
