package Client;
import java.sql.Connection;
import java.util.Scanner;

import Connect.DataConnect;
import Service.HospService;
public class Main 
{
   public static void main(String args[])
   {
	   Scanner sc=new Scanner(System.in);
	   HospService ser=new HospService();
	   Connection con=DataConnect.getConnect();
	   while(true)
	   {
		   System.out.println("\n======= Hospital Management System =======");
		   System.out.println("1. Register New Patient");
		   System.out.println("2. Register New Doctor");
		   System.out.println("3. Schedule Appointment");
		   System.out.println("4. Update Appointment");
		   System.out.println("5. Show All Appointments");
		   System.out.println("6. Show Appointment by Appointment ID");
		   System.out.println("7. Show Appointments by Doctor ID");
		   System.out.println("8. Show Appointments by Patient ID");
		   System.out.println("9. Cancel Appointment");
		   System.out.println("10. Exit");
		   System.out.print("Enter your choice: ");
	       int ch=sc.nextInt();
	       sc.nextLine();
	   
		   switch(ch)
		   {
		   case 1:
			   ser.registerPatient();
			   break;
		   case 2:
			   ser.registerDoctor();
			   break;
		   case 3:
			   ser.scheduleApp();
			   break;
		   case 4:
			   ser.updateApp();
			   break;
		   case 5:
			   ser.showApp();
			   break;
		   case 6:
			   ser.showAppById();
			   break;
		   case 7:
			   ser.showAppByDoctorId();
			   break;
		   case 8:
			   ser.showAppByPatientId();
			   break;	
		   case 9:
			   ser.cancelApp();
			   break;
		   case 10:
			   System.out.println("Exiting... Thank you!");
               return;
           default:
        	   System.out.println("Enter valid choice");
           
		   }
	   }
   }
}
