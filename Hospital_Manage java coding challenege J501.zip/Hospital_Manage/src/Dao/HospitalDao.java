package Dao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Connect.DataConnect;
import Exception.PatientIdNotFound;
import Model.Appointment;
import Model.Doctor;
import Model.Patient;
public class HospitalDao 
{
	Connection con;
	PreparedStatement stat;
	public HospitalDao()
	{
		   con=DataConnect.getConnect();
	}
	public void regPatient(Patient obj)
	{
		try
		{
		stat=con.prepareStatement("insert into patient (firstName, lastName, dateOfBirth, gender, contactNumber, address) values (?,?,?,?,?,?)");
		stat.setString(1, obj.getFirstName());
		stat.setString(2, obj.getLastName());
		stat.setDate(3, java.sql.Date.valueOf(obj.getDateOfBirth()));
		stat.setString(4, obj.getGender());
		stat.setString(5, obj.getContactNumber());
		stat.setString(6, obj.getAddress());
		
		int c=stat.executeUpdate();
		if(c>0)
		{
			System.out.println("Patient details inserted successfully");
		}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	public void docDetails(Doctor obj)
	{
		try
		{
		stat=con.prepareStatement("insert into doctor (firstName, lastName, specialization, contactNumber) values (?,?,?,?)");
		stat.setString(1, obj.getFirstName());
		stat.setString(2, obj.getLastName());
		stat.setString(3,obj.getSpecialization());
		stat.setString(4, obj.getContactNumber());
		
		int c=stat.executeUpdate();
		if(c>0)
		{
			System.out.println("Doctor details inserted successfully");
		}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	public boolean scheduleApp(Appointment obj)
	{
		try
		{
			//check p_id
			stat=con.prepareStatement("select firstname from patient where patientId=?");
			stat.setInt(1, obj.getPatientId());
			ResultSet rs=stat.executeQuery();
			if (!rs.next()) 
			{
	            throw new PatientIdNotFound("No such patient ID exists: " + obj.getPatientId());
	        }
			stat=con.prepareStatement("select firstname from doctor where doctorId=?");
			stat.setInt(1, obj.getDoctorId());
			ResultSet res=stat.executeQuery();
			if(!res.next())
			{
				System.out.println("No such doctor Id exists");
				return false;
			}
			
	    //insert		
		stat=con.prepareStatement("insert into appointment (patientId, doctorId, appointmentDate, description) values (?,?,?,?)");
		stat.setInt(1, obj.getPatientId());
		stat.setInt(2, obj.getDoctorId());
		stat.setDate(3, java.sql.Date.valueOf(obj.getAppointmentDate()));
		stat.setString(4, obj.getDescription());
		
		int c=stat.executeUpdate();
		if(c>0)
		{
			return true;
		}
        return false;
		}
		catch (PatientIdNotFound e) 
		{
			System.out.println(e.getMessage());
			return false;

	    } 
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return false;

		}
	}
	
	public boolean updateAppointment(Appointment obj)
	{
		try
		{
			//check app_id
			stat = con.prepareStatement("select * from appointment where appointmentId=?");
			stat.setInt(1, obj.getAppointmentId());
			ResultSet rs=stat.executeQuery();
			if(!rs.next())
			{
				System.out.println("No such appointment Id exists");
				return false;
			}
			//update
			stat = con.prepareStatement("UPDATE appointment SET patientId = ?, doctorId = ?, appointmentDate = ?, description = ? WHERE appointmentId = ?");
		    stat.setInt(1, obj.getPatientId());
		    stat.setInt(2, obj.getDoctorId());
		    stat.setDate(3, java.sql.Date.valueOf(obj.getAppointmentDate())); 
		    stat.setString(4, obj.getDescription());
		    stat.setInt(5, obj.getAppointmentId());
		    int rows = stat.executeUpdate();
		    if(rows>0)
		    {
				return true;
			}
		    return false;

		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return false;

		}
	}
	
	public void showAppointments() {
	    try 
	    {
	        stat = con.prepareStatement("SELECT * FROM appointment");
	        ResultSet rs = stat.executeQuery();

	        System.out.println("All Appointments:");
	        System.out.println("-----------------------------------------------------------");
	        System.out.printf("%-5s %-10s %-10s %-15s %-20s\n", "ID", "PatientID", "DoctorID", "Date", "Description");
	        System.out.println("-----------------------------------------------------------");

	        while (rs.next()) {
	            int id = rs.getInt("appointmentId");
	            int patientId = rs.getInt("patientId");
	            int doctorId = rs.getInt("doctorId");
	            Date date = rs.getDate("appointmentDate");
	            String desc = rs.getString("description");

	            System.out.printf("%-5d %-10d %-10d %-15s %-20s\n", id, patientId, doctorId, date, desc);
	        }

	    } 
	    catch (Exception e) 
	    {
	        System.out.println("Error retrieving appointments: " + e.getMessage());
	    }
	}
	public void showAppointmentsById(int id) {
	    try 
	    {
	        stat = con.prepareStatement("SELECT * FROM appointment where appointmentId=?");
	        stat.setInt(1, id);
	        ResultSet rs = stat.executeQuery();
	        if (!rs.next()) 
	        { 
	            System.out.println("No appointments found with id: " + id);
	            return;
	        }
	        System.out.println("Appointments of Id:"+id);
	        System.out.println("-----------------------------------------------------------");
	        System.out.printf(" %-10s %-10s %-15s %-20s\n", "PatientID", "DoctorID", "Date", "Description");
	        System.out.println("-----------------------------------------------------------");

	        while (rs.next()) {
	            int patientId = rs.getInt("patientId");
	            int doctorId = rs.getInt("doctorId");
	            Date date = rs.getDate("appointmentDate");
	            String desc = rs.getString("description");

	            System.out.printf(" %-10d %-10d %-15s %-20s\n", patientId, doctorId, date, desc);
	        }

	    } 
	    catch (Exception e) 
	    {
	        System.out.println("Error retrieving appointments: " + e.getMessage());
	    }
	}
	
	public void showAppointmentsByDoctorId(int id) 
	{
	    try 
	    {
	        stat = con.prepareStatement("SELECT * FROM appointment where doctorId=?");
	        stat.setInt(1, id);
	        ResultSet rs = stat.executeQuery();

	        if (!rs.next()) 
	        { 
	            System.out.println("No appointments found for Doctor ID: " + id);
	            return;
	        }
	        System.out.println("Appointments of doctor id: "+id);
	        System.out.println("-----------------------------------------------------------");
	        System.out.printf("%-5s %-10s %-10s %-15s %-20s\n", "ID", "PatientID", "DoctorID", "Date", "Description");
	        System.out.println("-----------------------------------------------------------");

	        while (rs.next()) {
	            int appid = rs.getInt("appointmentId");
	            int patientId = rs.getInt("patientId");
	            int doctorId = rs.getInt("doctorId");
	            Date date = rs.getDate("appointmentDate");
	            String desc = rs.getString("description");

	            System.out.printf("%-5d %-10d %-10d %-15s %-20s\n", appid, patientId, doctorId, date, desc);
	        }

	    } 
	    catch (Exception e) 
	    {
	        System.out.println("Error retrieving appointments: " + e.getMessage());
	    }
	}
	
	public void showAppointmentsBypatientId(int id) 
	{
	    try 
	    {
	        stat = con.prepareStatement("SELECT * FROM appointment where patientId=?");
	        stat.setInt(1, id);
	        ResultSet rs = stat.executeQuery();
	        if (!rs.next()) 
	        { 
	            System.out.println("No appointments found for patient ID: " + id);
	            return;
	        }
	        System.out.println("Appointments of patient id: "+id);
	        System.out.println("-----------------------------------------------------------");
	        System.out.printf("%-5s %-10s %-10s %-15s %-20s\n", "ID", "PatientID", "DoctorID", "Date", "Description");
	        System.out.println("-----------------------------------------------------------");

	        while (rs.next()) {
	            int appid = rs.getInt("appointmentId");
	            int patientId = rs.getInt("patientId");
	            int doctorId = rs.getInt("doctorId");
	            Date date = rs.getDate("appointmentDate");
	            String desc = rs.getString("description");

	            System.out.printf("%-5d %-10d %-10d %-15s %-20s\n", appid, patientId, doctorId, date, desc);
	        }

	    } 
	    catch (Exception e) 
	    {
	        System.out.println("Error retrieving appointments: " + e.getMessage());
	    }
	}
	
	public boolean cancelAppointment(int id) {
	    try 
	    {
	        // Check app exists
	        stat = con.prepareStatement("SELECT * FROM appointment WHERE appointmentId = ?");
	        stat.setInt(1, id);
	        ResultSet rs = stat.executeQuery();
	        if (!rs.next()) 
	        {
	            System.out.println("No appointment found with ID: " + id);
	            return false;
	        }

	        // Delete the appointment
	        stat = con.prepareStatement("DELETE FROM appointment WHERE appointmentId = ?");
	        stat.setInt(1, id);
	        int rows = stat.executeUpdate();

	        if (rows > 0) {
	            return true;
	        } 
	        else 
	        {
	            return false;
	        }

	    } catch (Exception e)
	    {
	        System.out.println("Error cancelling appointment: " + e.getMessage());
	        return false;
	    }
	}

	
}
