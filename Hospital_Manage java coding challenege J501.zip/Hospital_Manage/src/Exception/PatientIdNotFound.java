package Exception;

public class PatientIdNotFound extends Exception
{
	public PatientIdNotFound(String message) {
        super(message);
    }
}
