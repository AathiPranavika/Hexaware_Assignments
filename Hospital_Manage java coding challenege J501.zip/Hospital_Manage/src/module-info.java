/**
 * 
 */
/**
 * 
 */
module Hospital_Manage {
	requires java.sql;
}