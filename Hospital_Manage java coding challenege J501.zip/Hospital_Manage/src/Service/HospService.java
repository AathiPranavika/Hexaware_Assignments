package Service;
import java.time.LocalDate;
import java.util.Scanner;
import Dao.HospitalDao;
import Model.Appointment;
import Model.Doctor;
import Model.Patient;
public class HospService
{
	Scanner sc;
	HospitalDao hdao;
	 public HospService()
	 {
		 sc=new Scanner(System.in);
		 hdao=new HospitalDao();
	 }
	 
	 public void registerPatient()
	 {
		    System.out.print("Enter First Name: ");
	        String firstName = sc.nextLine();
	        if (firstName == null || firstName.trim().isEmpty()) {
	            System.out.println("First Name cannot be blank.");
	            return;
	        }
	        System.out.print("Enter Last Name: ");
	        String lastName = sc.nextLine();

	        System.out.print("Enter Date of Birth (YYYY-MM-DD): ");
	        String dateOfBirth = sc.nextLine();
	        LocalDate dob = LocalDate.parse(dateOfBirth);
	        
	        System.out.print("Enter Gender (Male/Female/Other): ");
	        String gender = sc.nextLine();

	        System.out.print("Enter Contact Number: ");
	        String contactNumber = sc.nextLine();
	        if (contactNumber.length()!=10)
	        {
	            System.out.println("Contact Number must be 10 digits.");
	            return;
	        }
	        System.out.print("Enter Address: ");
	        String address = sc.nextLine();
	        
	        Patient obj = new Patient(firstName, lastName, dob, gender, contactNumber, address);
            hdao.regPatient(obj);

	 }
	 public void registerDoctor()
	 {
		 System.out.print("Enter Doctor First Name: ");
	     String firstName = sc.nextLine();
	     if (firstName == null || firstName.trim().isEmpty()) {
	            System.out.println("First Name cannot be blank.");
	            return;
	        }
	     System.out.print("Enter Doctor Last Name: ");
	     String lastName = sc.nextLine();

	     System.out.print("Enter Specialization: ");
	     String specialization = sc.nextLine();

	     System.out.print("Enter Contact Number: ");
	     String contactNumber = sc.nextLine();
	     if (contactNumber.length()!=10)
	        {
	            System.out.println("Contact Number must be 10 digits.");
	            return;
	        }
	     Doctor doc = new Doctor(firstName, lastName, specialization, contactNumber);
	     hdao.docDetails(doc);
	 }
	 
	 public void scheduleApp()
	 {
		 System.out.print("Enter Patient ID: ");
	        int patientId = sc.nextInt();

	        System.out.print("Enter Doctor ID: ");
	        int doctorId = sc.nextInt();
	        sc.nextLine(); 

	        System.out.print("Enter Appointment Date (YYYY-MM-DD): ");
	        String appointmentDate = sc.nextLine();

	        System.out.print("Enter Description: ");
	        String description = sc.nextLine();

	        Appointment app = new Appointment(patientId, doctorId, appointmentDate, description);
	        boolean scheduled=hdao.scheduleApp(app);
	        if (scheduled) 
	        {
	            System.out.println("Appointment updated successfully.");
	        } 
	        else 
	        {
	            System.out.println("Update failed. Please check appointment ID.");
	        }
	        
	 }
	 
	 public void updateApp()
	 {
		    Appointment obj = new Appointment();

	        System.out.print("Enter Appointment ID to update: ");
	        obj.setAppointmentId(sc.nextInt());

	        System.out.print("Enter Patient ID: ");
	        obj.setPatientId(sc.nextInt());

	        System.out.print("Enter Doctor ID: ");
	        obj.setDoctorId(sc.nextInt());
	        sc.nextLine(); 

	        System.out.print("Enter Appointment Date (yyyy-MM-dd): ");
	        obj.setAppointmentDate(sc.nextLine());

	        System.out.print("Enter Description: ");
	        obj.setDescription(sc.nextLine());
	        
	        boolean updated = hdao.updateAppointment(obj);
	        if (updated) 
	        {
	            System.out.println("Appointment updated successfully.");
	        } 
	        else 
	        {
	            System.out.println("Update failed. Please check appointment ID.");
	        }
	 }
	 
	 public void showApp()
	 {
		 hdao.showAppointments();
	 }
	 
	 public void showAppById()
	 {
		 System.out.print("Enter appointment ID: ");
	     int AppointmentId = sc.nextInt();
		 hdao.showAppointmentsById(AppointmentId);
	 }
	 
	 public void showAppByDoctorId()
	 {
		 System.out.print("Enter doctor ID: ");
	     int DocId = sc.nextInt();
		 hdao.showAppointmentsByDoctorId(DocId);
	 }
	 
	 public void showAppByPatientId()
	 {
		 System.out.print("Enter patient ID: ");
	     int patId = sc.nextInt();
		 hdao.showAppointmentsBypatientId(patId);
	 }
	 
	 public void cancelApp()
	 {
		 System.out.print("Enter appointment ID to be canceled: ");
	     int AppointmentId = sc.nextInt();
		 boolean cancelled=hdao.cancelAppointment(AppointmentId);
		 if (cancelled) 
	        {
	            System.out.println("Appointment cancelled successfully.");
	        } 
	    else 
	        {
	            System.out.println("cancel failed. Please check appointment ID.");
	        }
	 }
	 
}